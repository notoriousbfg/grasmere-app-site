Academic CV: a curriculum vitae written in Markdown and typeset by LaTeX.
From https://grasmere.app/markdown/academic-cv-template.html. Free to use and change.

  academic-cv.tex   the template
  cv.md             an example CV to write over
  cv.pdf            what the example looks like

With Pandoc:
  pandoc cv.md --shift-heading-level-by=-1 --template academic-cv.tex -o cv.pdf

With no LaTeX installed, make the .tex and compile it in Overleaf:
  pandoc cv.md --shift-heading-level-by=-1 --template academic-cv.tex -o cv.tex

With Grasmere (1.6 or later): keep academic-cv.tex in your project, put your CV in hand,
and on the Publish stage click LaTeX and choose academic-cv as the template.
