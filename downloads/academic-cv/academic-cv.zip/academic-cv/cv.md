---
author: Rosa Field
---

# Curriculum Vitae

Department of History, University of Kelder, Fold End, Cumbria

rosa.field@kelder.example · [rosafield.example](https://rosafield.example)

## Research interests

Inland water transport in northern England, 1850–1950. Parish records as sources for economic history. The history of bread and domestic baking.

## Education

**PhD in History**, University of Kelder, 2023. Thesis: *Winter Crossings on Kelder Water, 1890–1940*. Supervisor: Professor Margaret Abbott.

**MA in Local and Regional History**, University of Kelder, 2018. Distinction.

**BA (Hons) in History**, Fold End College, 2016. First class.

## Appointments

**Lecturer in Modern British History**, University of Kelder, 2024 to present.

**Postdoctoral Research Fellow**, Lakeland Ferries Archive Project, 2023–2024.

## Publications

### Books

- *The Living Loaf: Bread and the Household in Northern England*. 2nd ed. London: Riverbank Press, 2019.

### Articles and chapters

- “The Boy Who Walked the Shore: Parish Relief and the Frozen Ferry.” *Journal of Lakeland History* 41, no. 2 (2024): 112–138.
- “Timetables as Evidence: Reading the Kelder Ferry, 1920–1960.” In *Ways Across Water*, edited by Tom Baker, 63–88. Kelder: Low Water Books, 2022.
- With Tom Baker. “Starters Are Alive.” *The Loaf* 7 (2019): 4–19.

## Grants and awards

- Kelder Historical Society Research Grant, 2025. £4,200, for archive visits.
- Fold End Prize for the best doctoral thesis in regional history, 2023.

## Talks

- “Low Water: A Ferry and Its Parish.” Northern History Forum, Kelder, March 2025.
- “What a Timetable Knows.” Archives and Records Day, Fold End, October 2023.

## Teaching

### University of Kelder

- Britain Since 1850, first-year survey. Module leader, 2024 to present.
- The Historian’s Sources, second-year methods. Seminar tutor, 2021–2023.
  - Designed the archive visit and its assessment.

## Service

- Reviews editor, *Journal of Lakeland History*, 2024 to present.
- Postgraduate representative, Department of History, 2020–2022.

## Referees

Professor Margaret Abbott, Department of History, University of Kelder. m.abbott@kelder.example
